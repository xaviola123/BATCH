package es.lacaixa.absis.batch.app.appapp.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import es.lacaixa.absis.batch.app.appapp.domain.BeanCliente;
import es.lacaixa.absis.batch.arch.reader.AbsisRowMapper;



	public class RowMapperAux implements AbsisRowMapper<List<BeanCliente>> {

		protected static Log logger = LogFactory.getLog(RowMapperAux.class);
		
		
		private String cpkCliente = "CPKCLIENTE";
		private String numCli = "NUMCLI";
		private String nombre = "NOMBRE";
		private String apellidos = "APELLIDOS";
		private String direccion = "DIRECCION";
		private String telefono = "TELEFONO";
		private String nif = "NIF";
		private String usuAlta = "USUALTA";
		private String timesStampAlta = "TIMESTAMPALTA";
		private String usuModif = "USUMODIF";
		private String timesStampModif = "TIMESTAMPMODIF";
		private String usuBaja = "USUBAJA";
		private String timesStampBaja = "TIMESTAMPBAJA";
		
		@Override
	public List<BeanCliente> mapRow(ResultSet rs, int rowNum) throws SQLException {
		
			List<BeanCliente>listaClientes = new ArrayList<>();
		if(rs !=null) {
			do {
				BeanCliente cliente = new BeanCliente();
				cliente.setCpkCliente(rs.getString(cpkCliente));
				cliente.setNumCli(rs.getString(numCli));
				cliente.setNombre(rs.getString(nombre));
				cliente.setApellidos(rs.getString(apellidos));
				cliente.setDireccion(rs.getString(direccion));
				cliente.setTelefono(rs.getString(telefono));
				cliente.setNif(rs.getString(nif));
				cliente.setUsualta(rs.getString(usuAlta));
				cliente.setTimestampalta(rs.getString(timesStampAlta));
				cliente.setUsumodif(rs.getString(usuModif));
				cliente.setTimestampmodif(rs.getString(timesStampModif));
				cliente.setUsubaja(rs.getString(usuBaja));
				cliente.setTimestampbaja(rs.getString(timesStampBaja));
				
				listaClientes.add(cliente);
			}while(rs.next());
		}
			
			
		
			
			return listaClientes;
		}
}
