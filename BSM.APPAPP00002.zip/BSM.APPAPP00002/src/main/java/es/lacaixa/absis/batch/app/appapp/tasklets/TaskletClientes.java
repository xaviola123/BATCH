package es.lacaixa.absis.batch.app.appapp.tasklets;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.core.io.Resource;

import es.lacaixa.absis.batch.app.appapp.domain.BeanCliente;
import es.lacaixa.absis.batch.app.appapp.util.Utilidades;

public class TaskletClientes implements Tasklet {

    protected static Log logger = LogFactory.getLog(TaskletClientes.class);
    private Resource ficheroClientes;

    public Resource getFicheroClientes() {
        return ficheroClientes;
    }

    public void setFicheroClientes(Resource ficheroClientes) {
        this.ficheroClientes = ficheroClientes;
    }

    @Override
    public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext) throws Exception {
        

        File archivoClientes = null;
        if (ficheroClientes != null) {
            archivoClientes = ficheroClientes.getFile();
        }

        if (archivoClientes == null) {

            return RepeatStatus.FINISHED;
        }

        BufferedReader readerClientes = new BufferedReader(new FileReader(archivoClientes));
        String linea = readerClientes.readLine();
        while (linea != null) {
            String atributos[] = linea.split(";");
            if (atributos.length < 6) {

                break;
            }

            BeanCliente cliente = new BeanCliente();
            cliente.setNumCli(atributos[0]);
            cliente.setNombre(atributos[1]);
            cliente.setApellidos(atributos[2]);
            cliente.setDireccion(atributos[3]);
            cliente.setTelefono(atributos[4]);
            cliente.setNif(atributos[5]);

            if (Boolean.TRUE.equals(Utilidades.isClientFilled(cliente))) {
                BeanCliente clienteAux = Utilidades.readerCliente(cliente.getNif());
                if (null != clienteAux && StringUtils.isNotBlank(clienteAux.getCpkCliente())) { // El Cliente ya Existe
                    Utilidades.doLoggerInfo("Cliente " + cliente.getNombre() + " ya existe en la BD");
                } else { // El Cliente no existe, se da de alta
                    Utilidades.doLoggerInfo("Cliente " + cliente.getNombre() + " se inserta en la BD");
                    cliente.setUsualta("BATCH");
                    Utilidades.writeCliente(cliente);
                }
            }
            linea = readerClientes.readLine();
        }

        readerClientes.close();

        return RepeatStatus.FINISHED;
    }
}
