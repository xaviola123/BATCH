package es.lacaixa.absis.batch.app.appapp.util;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.WordUtils;
import org.apache.commons.lang3.time.FastDateFormat;
import org.apache.commons.logging.Log;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;

public class BatchUtils {

	private static final int SIZE = 80;
	private static final char PAD = '-';
	private static final int MAX_LENGTH = 127;
	private static final String COMMA = ",";

	private BatchUtils() {
		throw new IllegalAccessError(this.getClass().getSimpleName());
	}

	public static String format(String string) {
		return StringUtils.isBlank(string) ? "" : string;
	}

	public static String logFormat(String string) {
		if (string == null) {
			return string;
		}

		string = ' ' + string + ' ';

		return BatchUtils.center(string, SIZE, PAD);
	}

	public static String separator() {
		return BatchUtils.center(String.valueOf(PAD), SIZE, PAD);
	}

	public static String separator(char pad) {
		return BatchUtils.center(String.valueOf(pad), SIZE, pad);
	}

	public static String center(String string, int size, char pad) {
		if (string == null || size <= string.length()) {
			return string;
		}

		StringBuilder stringBuilder = new StringBuilder(size);

		for (int i = 0; i < (size - string.length()) / 2; i++) {
			stringBuilder.append(pad);
		}

		stringBuilder.append(string);

		while (stringBuilder.length() < size) {
			stringBuilder.append(pad);
		}

		return stringBuilder.toString();
	}

	public static String zeroPadLeft(String string, int lenght) {
		string = StringUtils.left(string, lenght);
		return String.format("%0" + lenght + "d", Long.parseLong(string));
	}

	public static String spacePadRight(String string, int lenght) {
		string = StringUtils.left(string, lenght);
		return String.format("%1$-" + lenght + "s", string);
	}

	public static String wrap(String longString) {
		String resultString = "";

		if (longString == null) {
			return resultString;
		}

		WordUtils.wrap(longString, SIZE);

		return resultString;
	}

	public static String pad(String string) {
		if (StringUtils.isEmpty(string)) {
			return "";
		}

		return StringUtils.rightPad(string + " ", 52, '.') + ": ";
	}

	public static String tab(String string, int tab) {
		if (StringUtils.isEmpty(string)) {
			return "";
		}

		String prefix = "";

		switch (tab) {
		case 1:
			prefix = "- ";
			break;
		case 2:
			prefix = "  � ";
			break;
		case 3:
			prefix = "      � ";
			break;
		default:
			break;
		}

		return prefix + string;
	}

	public static String pad(String string, int tab) {
		if (StringUtils.isEmpty(string)) {
			return "";
		}

		return pad(tab(string, tab));
	}

	public static String escapeStringAsFilename(String string) {
		if (string == null) {
			return null;
		}

		string = string.replaceAll("[^a-zA-Z0-9.-]", "_");
		string = string.replaceAll("[:\\\\/*?|<>.]", "_");
		string = string.replaceAll("^_", "");
		string = string.replaceAll("_$", "");
		string = string.toLowerCase();

		if (string.length() > MAX_LENGTH) {
			string.substring(0, MAX_LENGTH);
		}

		return string;
	}

	public static String toTitleCase(String string) {
		if (string == null) {
			return null;
		}

		string = string.toLowerCase();

		StringBuilder titleCase = new StringBuilder();
		boolean nextTitleCase = true;

		for (char character : string.toCharArray()) {
			if (Character.isSpaceChar(character)) {
				nextTitleCase = true;
			} else if (nextTitleCase) {
				character = Character.toTitleCase(character);
				nextTitleCase = false;
			}

			titleCase.append(character);
		}

		return titleCase.toString();
	}

	public static <T> String getCommaSeperatedString(List<T> list) {
		if (CollectionUtils.isEmpty(list)) {
			return null;
		}

		StringBuilder stringBuilder = new StringBuilder();

		for (T element : list) {
			stringBuilder.append(element);
			stringBuilder.append(COMMA);
		}

		int position = stringBuilder.lastIndexOf(COMMA);
		stringBuilder.deleteCharAt(position);

		return stringBuilder.toString();
	}

	public static String formatDate(Date date, String format) {
		String formatedDate = "";

		if (date == null || StringUtils.isBlank(format)) {
			return formatedDate;
		}

		FastDateFormat dateFormat = FastDateFormat.getInstance(format);

		try {
			formatedDate = dateFormat.format(date);
		} catch (Exception exception) {
			formatedDate = "";
		}

		return formatedDate;
	}

	public static Date removeTime(Date date) {
		if (date == null) {
			return null;
		}

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);

		return calendar.getTime();
	}

	public static int compareDays(Date firstDate, Date secondDate) {
		firstDate = removeTime(firstDate);
		secondDate = removeTime(secondDate);

		return firstDate.compareTo(secondDate);
	}

	public static Date addDays(Date date, int days) {
		if (date == null) {
			return null;
		}

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.DATE, days);

		return calendar.getTime();
	}

	public static Date addMonths(Date date, int months) {
		if (date == null) {
			return null;
		}

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.MONTH, months);

		return calendar.getTime();
	}

	public static java.sql.Date toSqlDate(java.util.Date date) {
		if (date == null) {
			return null;
		}

		return new java.sql.Date(date.getTime());
	}

	public static JobExecution getJobExecution(ChunkContext chunkContext) {
		if (chunkContext == null) {
			return null;
		}

		StepContext stepContext = chunkContext.getStepContext();

		if (stepContext == null) {
			return null;
		}

		StepExecution stepExecution = stepContext.getStepExecution();

		if (stepExecution == null) {
			return null;
		}

		return stepExecution.getJobExecution();
	}

	public static JobInstance getJobInstance(ChunkContext chunkContext) {
		JobExecution jobExecution = getJobExecution(chunkContext);

		if (jobExecution == null) {
			return null;
		}

		return jobExecution.getJobInstance();
	}

	public static String getJobName(ChunkContext chunkContext) {
		JobInstance jobInstance = getJobInstance(chunkContext);

		if (jobInstance == null) {
			return null;
		}

		return jobInstance.getJobName();
	}

//	public static String getJobParameter(ChunkContext chunkContext, String key) {
//		JobInstance jobInstance = getJobInstance(chunkContext);
//
//		if (jobInstance == null) {
//			return null;
//		}
//
//		JobParameters jobParameters = jobInstance.getJobParameters();
//
//		if (jobParameters == null) {
//			return null;
//		}
//
//		return jobParameters.getString(key);
//	}

	public static void printStackTrace(Log log, StepExecution stepExecution) {
		if (log == null || stepExecution == null) {
			return;
		}

		List<Throwable> throwables = stepExecution.getFailureExceptions();

		if (CollectionUtils.isNotEmpty(throwables)) {
			for (Throwable throwable : throwables) {
				log.error(throwable.getMessage(), throwable);
			}
		}
	}
}