package es.lacaixa.absis.batch.app.appapp.filter;

import java.util.Arrays;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import es.lacaixa.absis.batch.app.appapp.domain.BeanCliente;
import es.lacaixa.absis.batch.arch.filter.AbsisItemFilter;

public class FilterLZ implements AbsisItemFilter<BeanCliente> {
	protected static Log logger = LogFactory.getLog(FilterLZ.class);
	
	 @Override
	    public boolean accept(BeanCliente beanCliente) {
		   
		   List<Character> letrasPermitidas = Arrays.asList('L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V','W','X','Y','Z');
			boolean resultado =false;
	    	
	    	char primeraLetraNombre = beanCliente.getNombre().toUpperCase().charAt(0);
	    	
	       if(beanCliente==null || beanCliente.getNombre() ==null || beanCliente.getNombre().isEmpty()) {
	    	   resultado = false;
	       }
	        if(letrasPermitidas.contains(primeraLetraNombre)) {
	        	resultado = true;
	        }
	        
	        
	        return resultado;
	        
	        
	    }
}
