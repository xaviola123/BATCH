package es.lacaixa.absis.batch.app.appapp.listener;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import es.lacaixa.absis.batch.app.appapp.util.BatchContextManager;
import es.lacaixa.absis.batch.arch.listener.AbsisJobStartListener;
import es.lacaixa.absis.batch.arch.util.BatchParams;

public class JobStartListener implements AbsisJobStartListener {

	protected static Log log = LogFactory.getLog(JobStartListener.class);

	

	public Map<String, Object> prepareJob(BatchParams batchParams) {
		if(log.isInfoEnabled()) {
		log.info("Arranca el proceso batch. Estamos en el JobStartListener.");
		}
		
		long start = System.currentTimeMillis();
		BatchContextManager.setStart(start);

		Map<String, Object> parametros = new HashMap<String, Object>();
		
		return parametros;
	}
}
