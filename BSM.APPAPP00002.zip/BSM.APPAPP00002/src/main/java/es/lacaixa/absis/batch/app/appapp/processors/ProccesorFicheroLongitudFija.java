package es.lacaixa.absis.batch.app.appapp.processors;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeanUtils;

import es.lacaixa.absis.batch.app.appapp.domain.BeanCMF;
import es.lacaixa.absis.batch.app.appapp.util.Utilidades;
import es.lacaixa.absis.batch.arch.internal.processor.AbsisGenericItemProcessor;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class ProccesorFicheroLongitudFija extends AbsisGenericItemProcessor<BeanCMF, BeanCMF> {
    protected static Log logger = LogFactory.getLog(ProccesorFicheroLongitudFija.class);

    @Override
    public BeanCMF process(BeanCMF inItem) throws Exception {
     
        BeanCMF outItem = new BeanCMF();
        BeanUtils.copyProperties(inItem, outItem);

        LocalDate fechaActual = LocalDate.now();
        LocalDate fechaLimite = fechaActual.minusYears(20);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        String fechaLimiteStr = fechaLimite.format(formatter);

        String fnacim = outItem.getFNACIM(); 
        if (fnacim != null && fnacim.length() > 1) {
            
          
            String fechaNacimientoStr = fnacim.substring(1);


            if (fechaNacimientoStr.compareTo(fechaLimiteStr) <= 0) {
               
                
                return outItem;
            }
        } 

       
        return null;
    }
}
