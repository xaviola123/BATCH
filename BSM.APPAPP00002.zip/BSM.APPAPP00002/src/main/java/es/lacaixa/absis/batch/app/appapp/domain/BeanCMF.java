package es.lacaixa.absis.batch.app.appapp.domain;

import java.io.Serializable;
import java.util.Objects;

@SuppressWarnings("serial")
public class BeanCMF implements Serializable {
	private String NUMPERSO;
	private String NOMPERSO;
	private String NIFPERSO;
	private String FINALCMF;
	private String CODLEI;
	private String DATCADLEI;
	private String FNACIM;
	
	
	

	public String getFNACIM() {
		return FNACIM;
	}

	public void setFNACIM(String fNACIM) {
		FNACIM = fNACIM;
	}

	public String getCODLEI() {
		return CODLEI;
	}

	public void setCODLEI(String cODLEI) {
		CODLEI = cODLEI;
	}

	public String getDATCADLEI() {
		return DATCADLEI;
	}

	public void setDATCADLEI(String dATCADLEI) {
		DATCADLEI = dATCADLEI;
	}

	public String getFINALCMF() {
		return FINALCMF;
	}

	public void setFINALCMF(String fINALCMF) {
		FINALCMF = fINALCMF;
	}

	public String getNUMPERSO() {
		return NUMPERSO;
	}

	public void setNUMPERSO(String nUMPERSO) {
		NUMPERSO = nUMPERSO;
	}

	public String getNOMPERSO() {
		return NOMPERSO;
	}

	public void setNOMPERSO(String nOMPERSO) {
		NOMPERSO = nOMPERSO;
	}

	public String getNIFPERSO() {
		return NIFPERSO;
	}

	public void setNIFPERSO(String nIFPERSO) {
		NIFPERSO = nIFPERSO;
	}

	@Override
	public int hashCode() {
		return Objects.hash(NIFPERSO, NOMPERSO, NUMPERSO);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BeanCMF other = (BeanCMF) obj;
		return Objects.equals(NIFPERSO, other.NIFPERSO) && Objects.equals(NOMPERSO, other.NOMPERSO)
				&& Objects.equals(NUMPERSO, other.NUMPERSO);
	}

	@Override
	public String toString() {
		return "BeanCMF [NUMPERSO=" + NUMPERSO + ", NOMPERSO=" + NOMPERSO + ", NIFPERSO=" + NIFPERSO + "]";
	}

}
