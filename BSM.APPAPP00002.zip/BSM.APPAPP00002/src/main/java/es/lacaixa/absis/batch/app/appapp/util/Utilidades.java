package es.lacaixa.absis.batch.app.appapp.util;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;

import es.lacaixa.absis.batch.app.appapp.domain.BeanCliente;
import es.lacaixa.absis.batch.app.appapp.mappers.RowMapperAux;
import es.lacaixa.absis.batch.app.appapp.mappers.RowMapperCliente;
import es.lacaixa.absis.batch.arch.internal.reader.AbsisBaseRowMapper;
import es.lacaixa.absis.batch.arch.internal.reader.AbsisJdbcItemReader;
import es.lacaixa.absis.batch.arch.internal.writer.AbsisJdbcItemWriter;
import es.lacaixa.absis.batch.arch.util.BatchContext;

public class Utilidades {

	private Utilidades() {
		super();
	}

	protected static Log logger = LogFactory.getLog(Utilidades.class);

	/**
	 * devuelve un cliente objeto
	 * 
	 * @param nif
	 * @return
	 */
	public static BeanCliente readerCliente(String nif) {

		BeanCliente cliente = new BeanCliente();
		List<BeanCliente> listaClientes = new ArrayList<BeanCliente>();

		BatchContext bc = BatchContext.getInstance();

		ExecutionContext executionContext = new ExecutionContext();

		@SuppressWarnings("rawtypes")
		JdbcCursorItemReader obReader = new JdbcCursorItemReader();

		@SuppressWarnings("rawtypes")
		AbsisBaseRowMapper absisRowMapper = new AbsisBaseRowMapper();

		RowMapperCliente rowMapperCliente = new RowMapperCliente();
		absisRowMapper.setRowMapper(rowMapperCliente);

		obReader = (AbsisJdbcItemReader) bc.getxmlContext().getBean("ReaderBBDD");
		obReader.setRowMapper(absisRowMapper);

		String sql = "select APELLIDOS , CPKCLIENTE , DIRECCION , NIF , NOMBRE , NUMCLI , TELEFONO , TIMESTAMPALTA , TIMESTAMPBAJA , TIMESTAMPMODIF , USUALTA , USUBAJA , USUMODIF  from TDE_CLIENTE";
		obReader.close();
		obReader.setSql(sql);
		obReader.open(executionContext);
		obReader.setVerifyCursorPosition(false);

		try {

			cliente = (BeanCliente) obReader.read();

		} catch (UnexpectedInputException e) {

			logger.info(e.getMessage());

			throw new UnexpectedInputException(e.toString());
		} catch (org.springframework.batch.item.ParseException e) {

			logger.info(e.getMessage());

			throw new org.springframework.batch.item.ParseException(e.toString());
		} catch (Exception e) {

			logger.info(e.getMessage());

			throw new RuntimeException(e.toString());
		} finally {

			obReader.close();
		}

		return cliente;
	}

	/**
	 * devuveve una lista de clientes 
	 * 
	 * @return
	 */
	public static List<BeanCliente> readerClienteTasklet() {

		BeanCliente cliente = new BeanCliente();
		List<BeanCliente> listaClientes = new ArrayList<BeanCliente>();

		BatchContext bc = BatchContext.getInstance();

		ExecutionContext executionContext = new ExecutionContext();

		@SuppressWarnings("rawtypes")
		JdbcCursorItemReader obReader = new JdbcCursorItemReader();

		@SuppressWarnings("rawtypes")
		AbsisBaseRowMapper absisRowMapper = new AbsisBaseRowMapper();

		RowMapperAux rowMapperAux = new RowMapperAux();
		absisRowMapper.setRowMapper(rowMapperAux);

		obReader = (AbsisJdbcItemReader) bc.getxmlContext().getBean("ReaderAux");
		obReader.setRowMapper(absisRowMapper);

		String sql = "select APELLIDOS , CPKCLIENTE , DIRECCION , NIF , NOMBRE , NUMCLI , TELEFONO , TIMESTAMPALTA , TIMESTAMPBAJA , TIMESTAMPMODIF , USUALTA , USUBAJA , USUMODIF  from TDE_CLIENTE";
		
		obReader.setSql(sql);
		obReader.open(executionContext);
		obReader.setVerifyCursorPosition(false);

		try {

			listaClientes = (List<BeanCliente>) obReader.read();

		} catch (UnexpectedInputException e) {

			logger.info(e.getMessage());

			throw new UnexpectedInputException(e.toString());
		} catch (org.springframework.batch.item.ParseException e) {

			logger.info(e.getMessage());

			throw new org.springframework.batch.item.ParseException(e.toString());
		} catch (Exception e) {

			logger.info(e.getMessage());

			throw new RuntimeException(e.toString());
		} finally {

			obReader.close();
		}

		return listaClientes;
	}

	public static void logPrint(Object object) {

		Boolean findObject = Boolean.FALSE;

		if (null != object && logger.isInfoEnabled()) {
			// StepContribution
			if (object instanceof StepContribution) {
				findObject = Boolean.TRUE;
				logger.info(object.getClass() + "\n" + "ExitStatus " + ((StepContribution) object).getExitStatus()
						+ "\n" + "FilterCount " + ((StepContribution) object).getFilterCount() + "\n"
						+ "ProcessSkipCount " + ((StepContribution) object).getProcessSkipCount() + "\n" + "ReadCount "
						+ ((StepContribution) object).getReadCount() + "\n" + "ReadSkipCount "
						+ ((StepContribution) object).getReadSkipCount() + "\n " + "SkipCount "
						+ ((StepContribution) object).getSkipCount() + "\n" + "StepSkipCount "
						+ ((StepContribution) object).getStepSkipCount() + "\n" + "WriteCount "
						+ ((StepContribution) object).getWriteCount() + "\n" + "WriteSkipCount "
						+ ((StepContribution) object).getWriteSkipCount());
			}
			// BeanCliente
			if (object instanceof BeanCliente) {
				findObject = Boolean.TRUE;
				logger.info(object.getClass() + "\n" + "CpkCliente: " + ((BeanCliente) object).getCpkCliente() + "\n"
						+ "NumCli: " + ((BeanCliente) object).getNumCli() + "\n" + "Nombre: "
						+ ((BeanCliente) object).getNombre() + "\n" + "Apellidos: "
						+ ((BeanCliente) object).getApellidos() + "\n" + "Direcci�n: "
						+ ((BeanCliente) object).getDireccion() + "\n " + "Tel�fono: "
						+ ((BeanCliente) object).getTelefono() + "\n" + "Nif: " + ((BeanCliente) object).getNif() + "\n"
						+ "UsuAlta " + ((BeanCliente) object).getUsualta() + "\n" + "TimeStampAlta: "
						+ ((BeanCliente) object).getTimestampalta() + "\n" + "UsuModif: "
						+ ((BeanCliente) object).getUsumodif() + "\n" + "TimeStampModif "
						+ ((BeanCliente) object).getTimestampmodif() + "\n" + "UsuBaja "
						+ ((BeanCliente) object).getUsubaja() + "\n" + "TimeStampBaja "
						+ ((BeanCliente) object).getTimestampbaja());
			}

			if (object instanceof String) {
				findObject = Boolean.TRUE;
				logger.info(object.toString());
			}

			if (Boolean.FALSE.equals(findObject))
				logger.info("No se ha podido imprimir en el log el objeto: " + object.getClass());
		} else {
			if (logger.isInfoEnabled())
				logger.info("Objeto nulo");
		}
	}

	public static Boolean isClientFilled(BeanCliente cliente) {

		Boolean filled = Boolean.TRUE;

		if (null == cliente || StringUtils.isBlank(cliente.getNumCli()) || StringUtils.isBlank(cliente.getNombre())
				|| StringUtils.isBlank(cliente.getApellidos()) || StringUtils.isBlank(cliente.getDireccion())
				|| StringUtils.isBlank(cliente.getTelefono()) || StringUtils.isBlank(cliente.getNif())) {

			if (logger.isInfoEnabled()) {
				logger.info("El cliente no tiene los datos completos");
				logPrint(cliente);
			}
			filled = Boolean.FALSE;

		}

		return filled;

	}

	public static void writeCliente(BeanCliente beanCliente) {
		List<BeanCliente> listaClientes = new ArrayList<>();
		listaClientes.add(beanCliente);

		BatchContext bc = BatchContext.getInstance();
		@SuppressWarnings("rawtypes")
		JdbcBatchItemWriter obWriter = (AbsisJdbcItemWriter) bc.getxmlContext().getBean("WriterBD");

		try {
			obWriter.write(listaClientes);
			doLoggerInfo(
					"Utilidades.writeCliente: Se ha dado de alta " + beanCliente.getNif() + beanCliente.getNombre());

		} catch (Exception e) {
			doLoggerInfo(e.getMessage());
			throw new RuntimeException(e.toString());
		}
	}

	public static void doLoggerInfo(String msg) {
		if (logger.isInfoEnabled()) {
			logger.info(msg);
		}
	}

}
