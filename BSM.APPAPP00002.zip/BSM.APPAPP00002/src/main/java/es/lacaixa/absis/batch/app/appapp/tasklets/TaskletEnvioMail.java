package es.lacaixa.absis.batch.app.appapp.tasklets;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.BeanUtils;
import org.springframework.core.io.Resource;

import es.lacaixa.absis.batch.app.appapp.domain.BeanCliente;
import es.lacaixa.absis.batch.app.appapp.util.Utilidades;
import es.lacaixa.absis.batch.arch.internal.beans.AbsisMailSenderBean;
import es.lacaixa.absis.batch.arch.internal.generics.AbsisMailSender;

public class TaskletEnvioMail implements Tasklet{
	protected static Log logger = LogFactory.getLog(TaskletEnvioMail.class);
	private Resource ficheroClientes;
	private static final String FROM = "documentacion@caixabank.com";
	private static final String TO = "Manuela@viewnext.com";
	private static final String SUBJECT = "Clientes Descartados";
	   
	
	public Resource getFicheroClientes() {
		return ficheroClientes;
	}

	public void setFicheroClientes(Resource ficheroClientes) {
		this.ficheroClientes = ficheroClientes;
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		
		
		Utilidades.logPrint(contribution);
		if (logger.isInfoEnabled()) logger.info("Se est� ejecutando la TASKLET");
		
		File archivoClientes = null;
		
		if (ficheroClientes != null) {
			archivoClientes = ficheroClientes.getFile();
		}
		
		if (archivoClientes == null) {
			if (logger.isInfoEnabled()) {
				logger.info("No se ha encontrado el archivo de entrada");
			}
			return RepeatStatus.FINISHED;
		}
		
		AbsisMailSenderBean bm = new AbsisMailSenderBean();
		// Setear el bean seg�n las necesidades de env�o
		bm.setFrom(FROM);
		bm.setTo(TO);
		bm.setSubject(SUBJECT);		
		
		
		// Adjuntamos el fichero de entrada donde tenemos los nuevos clientes
		ArrayList<File> attachments = new ArrayList<>();
		attachments.add(archivoClientes);
		bm.setAttachments(attachments);
		
		//Cuerpo del email
		StringBuilder body = new StringBuilder();		
		String template = "<!DOCTYPE html><html>" + "<head><style>table '{table-layout: fixed;width: 700px;}'</style>"
				+ "</head>" + "<body style= \"font-family:courier\">";
		body.append(template);
		
		BufferedReader readerClientes = new BufferedReader(new FileReader(archivoClientes));
		String linea = readerClientes.readLine();
		while (linea != null) {
			BeanCliente cliente = new BeanCliente();
			String atributos[] = linea.split(";");
			cliente.setNumCli(atributos[0]);
			cliente.setNombre(atributos[1]);
			cliente.setApellidos(atributos[2]);
			cliente.setDireccion(atributos[3]);
			cliente.setTelefono(atributos[4]);
			cliente.setNif(atributos[5]);		
			
			
			if (Boolean.FALSE.equals(Utilidades.isClientFilled(cliente))){
				body.append("<p>Cliente con datos incompletos</p>");
				;
				body.append("<p>" + cliente.toString() + "</p>");
				
				
			}else if (null != Utilidades.readerCliente(cliente.getNif())) {
				body.append("<p>Cliente ya existia previamente en BBDD</p>");
				
				body.append("<p>" + cliente.toString() + "</p>");
							
			}
			linea = readerClientes.readLine();
		}
		
		body.append("<div style= \"font-family:courier;color:gray; \" >");
		body.append("<p style=\"LINE-HEIGHT:1.0;\" > ---------------------------------------------------------------------------------------<br/>");
		body.append(" Este mensaje ha sido enviado desde una direcci�n de correo electr�nico destinada <br/> ");
		body.append("solamente al env�o de notificaciones y que no recibe mensajes entrantes.<br/> ");
		body.append("<p align=\"justify\"> Por favor, no responda a este mensaje.<p/>");
		body.append(" ---------------------------------------------------------------------------------------<br/>");
		
		bm.setBody(body.toString());
		
		readerClientes.close();
		

		AbsisMailSender ms = new AbsisMailSender();
		ms.setbMail(bm);

		
		
		return RepeatStatus.FINISHED;
	}
	

}
