package es.lacaixa.absis.batch.app.appapp.listener;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import es.lacaixa.absis.batch.app.appapp.util.BatchContextManager;
import es.lacaixa.absis.batch.arch.listener.AbsisJobEndListener;
import es.lacaixa.absis.batch.arch.util.BatchParams;
public class JobEndListener implements AbsisJobEndListener {
	protected static Log log = LogFactory.getLog(JobEndListener.class);

	private static final String FORMATO_FECHA = "yyyy/MM/dd HH:mm";
	private final SimpleDateFormat dateFormat = new SimpleDateFormat(FORMATO_FECHA);

	@Override
	public void doAfterJob(BatchParams arg0) {
		mostrarEstadisticas();

	}

	private void mostrarEstadisticas() {
		long start = BatchContextManager.getStart();
		long end = System.currentTimeMillis();
		int seg = (int) ((end-start)/1000);
		int miliSeg = (int) ((end-start) - (seg*1000));

		Date dateStart = new Date(start);
		Date  dateEnd= new Date(end);

		log.info("Info Listener");
		log.info("BATCH -> " + BatchContextManager.getBatchParams().getJobName());
		
		log.info("VERSION: 0.0.1");
		log.info("Numero de pactos escritos: " + BatchContextManager.getBatchParams().getComponentes().size());
		log.info("---------Timepo----------------------");

		log.info("Fecha de inicio: " + dateFormat.format(dateStart));
		log.info("Fecha de fin: " + dateFormat.format(dateEnd));
		log.info("Tiempo de ejecucion: " + seg +" s " + miliSeg + " ms");
	}
}