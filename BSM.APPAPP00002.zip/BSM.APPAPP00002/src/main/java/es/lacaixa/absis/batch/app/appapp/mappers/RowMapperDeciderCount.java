package es.lacaixa.absis.batch.app.appapp.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import es.lacaixa.absis.batch.arch.reader.AbsisRowMapper;

public class RowMapperDeciderCount implements AbsisRowMapper<Integer> {

	private String cpkCliente = "COUNT(CPKCLIENTE)";
	
	@Override
	public Integer mapRow(ResultSet rs, int arg1) throws SQLException {
		
		return rs.getInt(cpkCliente);
	}

}