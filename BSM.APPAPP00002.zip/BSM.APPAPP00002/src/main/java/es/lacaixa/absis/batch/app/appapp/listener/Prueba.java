package es.lacaixa.absis.batch.app.appapp.listener;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.batch.core.annotation.BeforeStep;

public class Prueba {

	protected static Log logger = LogFactory.getLog(Prueba.class);
	
	@BeforeStep
	public void beforeStep() throws Exception {
		
		logger.info("Entra en el listener");
		
	}
	
}
