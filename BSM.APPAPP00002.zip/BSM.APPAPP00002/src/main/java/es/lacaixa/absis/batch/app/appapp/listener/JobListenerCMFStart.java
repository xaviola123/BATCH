package es.lacaixa.absis.batch.app.appapp.listener;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.core.listener.StepExecutionListenerSupport;

import es.lacaixa.absis.batch.app.appapp.util.BatchContextManager;

public class JobListenerCMFStart extends StepExecutionListenerSupport {
    protected static Log log = LogFactory.getLog(JobListenerCMFStart.class);

    private static final String FORMATO_FECHA = "yyyy/MM/dd HH:mm";
    private final SimpleDateFormat dateFormat = new SimpleDateFormat(FORMATO_FECHA);

    @AfterStep
    public void mostrarEstadisticas(StepExecution stepExecution) {
        long start = BatchContextManager.getStart();
        long end = System.currentTimeMillis();
        int seg = (int) ((end - start) / 1000);
        int miliSeg = (int) ((end - start) - (seg * 1000));

        Date dateStart = new Date(start);
        Date dateEnd = new Date(end);

        log.info("******************** Info Listener CFM **********");
        log.info("BATCH -> " + BatchContextManager.getBatchParams().getJobName());
        log.info("VERSION: 0.0.1");

        if (stepExecution != null) {
            log.info("Step Name: " + stepExecution.getStepName());
            log.info("Número de líneas leídas: " + stepExecution.getReadCount());
            log.info("Número de líneas escritas: " + stepExecution.getWriteCount());
        } else {
            log.warn("StepExecution no está disponible.");
        }

        log.info("Fecha de inicio: " + dateFormat.format(dateStart));
        log.info("Fecha de fin: " + dateFormat.format(dateEnd));
        log.info("Tiempo de ejecución: " + seg + " s " + miliSeg + " ms");
    }
}

