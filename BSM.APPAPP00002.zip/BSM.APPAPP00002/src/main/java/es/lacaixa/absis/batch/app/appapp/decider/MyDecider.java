package es.lacaixa.absis.batch.app.appapp.decider;


import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.job.flow.FlowExecutionStatus;
import org.springframework.batch.core.job.flow.JobExecutionDecider;

import es.lacaixa.absis.batch.app.appapp.util.BatchContextManager;
import es.lacaixa.absis.batch.app.appapp.util.Utilidades;

public class MyDecider implements JobExecutionDecider{

	@Override
	public FlowExecutionStatus decide(JobExecution jobExecution, StepExecution stepExecution) {
		if (stepExecution.getWriteCount()>0) {
			return FlowExecutionStatus.COMPLETED;
		} else {
			return FlowExecutionStatus.FAILED;
		}
		
	}

}