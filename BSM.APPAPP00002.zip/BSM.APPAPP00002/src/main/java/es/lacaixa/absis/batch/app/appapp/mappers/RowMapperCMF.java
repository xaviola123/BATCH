package es.lacaixa.absis.batch.app.appapp.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import es.lacaixa.absis.batch.app.appapp.domain.BeanCMF;
import es.lacaixa.absis.batch.arch.reader.AbsisRowMapper;

public class RowMapperCMF implements AbsisRowMapper<BeanCMF> {
	private String NUMPERSO ="NUMPERSO";
	private String  NOMPERSO="NOMPERSO";
	private String NIFPERSO ="NIFPERSO";
	
	@Override
	public BeanCMF mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		BeanCMF beanCmf = new BeanCMF();
		
		beanCmf.setNUMPERSO(rs.getString(NUMPERSO));
		beanCmf.setNOMPERSO(rs.getString(NOMPERSO));
		beanCmf.setNIFPERSO(rs.getString(NIFPERSO));
	
		return beanCmf;
	}

}
