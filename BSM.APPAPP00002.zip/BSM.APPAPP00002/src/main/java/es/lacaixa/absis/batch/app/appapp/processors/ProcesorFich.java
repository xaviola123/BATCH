package es.lacaixa.absis.batch.app.appapp.processors;


import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeanUtils;

import es.lacaixa.absis.batch.app.appapp.domain.BeanCliente;
import es.lacaixa.absis.batch.app.appapp.util.Utilidades;
import es.lacaixa.absis.batch.arch.internal.processor.AbsisGenericItemProcessor;


public class ProcesorFich extends AbsisGenericItemProcessor<BeanCliente, BeanCliente>{
	protected static Log logger = LogFactory.getLog(ProcesorFich.class);
	public static final String USU_ALTA_BATCH = "BATCH";
	
	 

	    @Override
	    public BeanCliente process(BeanCliente inItem) throws Exception {

	        BeanCliente outItem = new BeanCliente();

	        BeanUtils.copyProperties(inItem, outItem);

	        if (Boolean.TRUE.equals(Utilidades.isClientFilled(outItem))) {
	            BeanCliente clienteAux = Utilidades.readerCliente(outItem.getNif());
	            if (null != clienteAux && StringUtils.isNotBlank(clienteAux.getCpkCliente())) {
	                /*
	                 * Existe el cliente, ponemos a null el atributo numCli para descartarlo en el filter del writer
	                 */
	                outItem.setNumCli(null);
	                if (logger.isInfoEnabled()) {
	                    logger.info("Cliente con nif " + clienteAux.getNif() + "ya existe en BD");
	                    Utilidades.logPrint(clienteAux);
	                }
	            }
	        } 

	        outItem.setUsualta(USU_ALTA_BATCH);

	        Utilidades.logPrint(outItem);

	        return outItem;
	    }
}