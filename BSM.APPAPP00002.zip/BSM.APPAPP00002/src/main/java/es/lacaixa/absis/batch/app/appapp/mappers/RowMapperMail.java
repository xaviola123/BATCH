package es.lacaixa.absis.batch.app.appapp.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import es.lacaixa.absis.batch.app.appapp.domain.BeanMail;
import es.lacaixa.absis.batch.arch.reader.AbsisRowMapper;

public class RowMapperMail implements AbsisRowMapper<BeanMail>{

	protected static Log logger = LogFactory.getLog(RowMapperMail.class);
	private static String ESPACIO = " ";
	
	public BeanMail mapRow (ResultSet rs, int rowNum) throws SQLException {
	
		BeanMail bean = new BeanMail(); 
		bean.setBody(rs.getString("NOMBRE") + ESPACIO + rs.getString("APELLIDOS") + ESPACIO + rs.getString("DIRECCION"));
		
		return bean;
		
	}
	
}