package es.lacaixa.absis.batch.app.appapp.domain;



import java.io.Serializable;


public class BeanCliente implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String cpkCliente;
	private String numCli;
	private String nombre;
	private String apellidos;
	private String direccion;	
	private String telefono;
	private String nif;
	private String usualta;
	private String timestampalta;
	private String usumodif;
	private String timestampmodif;
	private String usubaja;
	private String timestampbaja;
	
	/**
	 * @return the cpkCliente
	 */
	public String getCpkCliente() {
		return cpkCliente;
	}
	/**
	 * @param cpkCliente the cpkCliente to set
	 */
	public void setCpkCliente(String cpkCliente) {
		this.cpkCliente = cpkCliente;
	}
	/**
	 * @return the numCli
	 */
	public String getNumCli() {
		return numCli;
	}
	/**
	 * @param numCli the numCli to set
	 */
	public void setNumCli(String numCli) {
		this.numCli = numCli;
	}
	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}
	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/**
	 * @return the apellidos
	 */
	public String getApellidos() {
		return apellidos;
	}
	/**
	 * @param apellidos the apellidos to set
	 */
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	/**
	 * @return the direccion
	 */
	public String getDireccion() {
		return direccion;
	}
	/**
	 * @param direccion the direccion to set
	 */
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	/**
	 * @return the telefono
	 */
	public String getTelefono() {
		return telefono;
	}
	/**
	 * @param telefono the telefono to set
	 */
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	/**
	 * @return the nif
	 */
	public String getNif() {
		return nif;
	}
	/**
	 * @param nif the nif to set
	 */
	public void setNif(String nif) {
		this.nif = nif;
	}
	/**
	 * @return the usualta
	 */
	public String getUsualta() {
		return usualta;
	}
	/**
	 * @param usualta the usualta to set
	 */
	public void setUsualta(String usualta) {
		this.usualta = usualta;
	}
	/**
	 * @return the timestampalta
	 */
	public String getTimestampalta() {
		return timestampalta;
	}
	/**
	 * @param timestampalta the timestampalta to set
	 */
	public void setTimestampalta(String timestampalta) {
		this.timestampalta = timestampalta;
	}
	/**
	 * @return the usumodif
	 */
	public String getUsumodif() {
		return usumodif;
	}
	/**
	 * @param usumodif the usumodif to set
	 */
	public void setUsumodif(String usumodif) {
		this.usumodif = usumodif;
	}
	/**
	 * @return the timestampmodif
	 */
	public String getTimestampmodif() {
		return timestampmodif;
	}
	/**
	 * @param timestampmodif the timestampmodif to set
	 */
	public void setTimestampmodif(String timestampmodif) {
		this.timestampmodif = timestampmodif;
	}
	/**
	 * @return the usubaja
	 */
	public String getUsubaja() {
		return usubaja;
	}
	/**
	 * @param usubaja the usubaja to set
	 */
	public void setUsubaja(String usubaja) {
		this.usubaja = usubaja;
	}
	/**
	 * @return the timestampbaja
	 */
	public String getTimestampbaja() {
		return timestampbaja;
	}
	/**
	 * @param timestampbaja the timestampbaja to set
	 */
	public void setTimestampbaja(String timestampbaja) {
		this.timestampbaja = timestampbaja;
	}
	@Override
	public String toString() {
		return "BeanCliente [cpkCliente=" + cpkCliente + ", numCli=" + numCli + ", nombre=" + nombre + ", apellidos="
				+ apellidos + ", direccion=" + direccion + ", telefono=" + telefono + ", nif=" + nif + ", usualta="
				+ usualta + ", timestampalta=" + timestampalta + ", usumodif=" + usumodif + ", timestampmodif="
				+ timestampmodif + ", usubaja=" + usubaja + ", timestampbaja=" + timestampbaja + "]";
	}
	
	
	

}
