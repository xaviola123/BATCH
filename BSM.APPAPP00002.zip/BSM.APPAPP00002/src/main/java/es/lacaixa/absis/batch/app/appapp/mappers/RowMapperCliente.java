package es.lacaixa.absis.batch.app.appapp.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import es.lacaixa.absis.batch.app.appapp.domain.BeanCliente;
import es.lacaixa.absis.batch.arch.reader.AbsisRowMapper;

public class RowMapperCliente implements AbsisRowMapper<BeanCliente> {

	protected static Log logger = LogFactory.getLog(RowMapperCliente.class);
	
	
	private String cpkCliente = "CPKCLIENTE";
	private String numCli = "NUMCLI";
	private String nombre = "NOMBRE";
	private String apellidos = "APELLIDOS";
	private String direccion = "DIRECCION";
	private String telefono = "TELEFONO";
	private String nif = "NIF";
	private String usuAlta = "USUALTA";
	private String timesStampAlta = "TIMESTAMPALTA";
	private String usuModif = "USUMODIF";
	private String timesStampModif = "TIMESTAMPMODIF";
	private String usuBaja = "USUBAJA";
	private String timesStampBaja = "TIMESTAMPBAJA";
	

public BeanCliente mapRow(ResultSet resultSet, int rowNum) throws SQLException {
		
		BeanCliente cliente = new BeanCliente();
		
		cliente.setCpkCliente(resultSet.getString(cpkCliente));
		cliente.setNumCli(resultSet.getString(numCli));
		cliente.setNombre(resultSet.getString(nombre));
		cliente.setApellidos(resultSet.getString(apellidos));
		cliente.setDireccion(resultSet.getString(direccion));
		cliente.setTelefono(resultSet.getString(telefono));
		cliente.setNif(resultSet.getString(nif));
		cliente.setUsualta(resultSet.getString(usuAlta));
		cliente.setTimestampalta(resultSet.getString(timesStampAlta));
		cliente.setUsumodif(resultSet.getString(usuModif));
		cliente.setTimestampmodif(resultSet.getString(timesStampModif));
		cliente.setUsubaja(resultSet.getString(usuBaja));
		cliente.setTimestampbaja(resultSet.getString(timesStampBaja));
		
	
		
		return cliente;
	}
}
