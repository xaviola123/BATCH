package es.lacaixa.absis.batch.app.appapp.processors;



import es.lacaixa.absis.batch.app.appapp.domain.BeanMail;
import es.lacaixa.absis.batch.arch.internal.beans.AbsisMailSenderBean;
import es.lacaixa.absis.batch.arch.internal.processor.AbsisGenericItemProcessor;

public class ProcesorEnvio extends AbsisGenericItemProcessor<BeanMail,AbsisMailSenderBean>{

	@Override
	public AbsisMailSenderBean process(BeanMail inItem) throws Exception {
		

		 AbsisMailSenderBean msb = new AbsisMailSenderBean();
	     msb.setFrom("documentacion@caixabank.com");
	   
	     msb.setTo("javier.cobillonP@viewnext.com");              
	     msb.setSubject("Prueba env�o email BSM");
	     msb.setBody(inItem.getBody());
	      
	     return msb;
			
	}

}
