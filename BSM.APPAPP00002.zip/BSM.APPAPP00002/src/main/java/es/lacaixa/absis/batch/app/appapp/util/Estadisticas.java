package es.lacaixa.absis.batch.app.appapp.util;

public class Estadisticas {

	public static final String ESTADISTICAS = "ESTADISTICAS";

	private long numeroRegistros;
	private static String tiempoInicializarArchivos="";
	private static String tiempoEjecucion = "";
	private static String tiempoEjecucionQueryInicial ="";
	private static String tiempoEjecucionAltaCentros ="";
	private static String tiempoEjecucionBajaCentros ="";
	private static String tiempoEjecucionCambioNombres ="";
	private static String tiempoEjecucionAltaAutorizados ="";
	private static String tiempoEjecucionBajasAutorizados ="";
	private static String tiempoEjecucionRegistrosManualesSemanaPasada ="";
	private static String tiempoEjecucionRegistrosManualesSemanaActual ="";
	private static String tiempoEjecucionQueryRegistrosManuales ="";
	private static String tiempoEjecucionFicheros="";
	private static String tiempoEjecucionInsercionAltaAutorizados ="";
	private static String tiempoEjecucionInsercionBajasAutorizados ="";
	private static String tiempoEjecucionInsercionAltasManuales ="";
	private static String tiempoEjecucionInsercionBajasManuales ="";
	public static String getTiempoInicializarArchivos() {
		return tiempoInicializarArchivos;
	}
	public static void setTiempoInicializarArchivos(String tiempoInicializarArchivos) {
		Estadisticas.tiempoInicializarArchivos = tiempoInicializarArchivos;
	}
	public static String getTiempoEjecucion() {
		return tiempoEjecucion;
	}
	public static void setTiempoEjecucion(String tiempoEjecucion) {
		Estadisticas.tiempoEjecucion = tiempoEjecucion;
	}
	public static String getTiempoEjecucionQueryInicial() {
		return tiempoEjecucionQueryInicial;
	}
	public static void setTiempoEjecucionQueryInicial(String tiempoEjecucionQueryInicial) {
		Estadisticas.tiempoEjecucionQueryInicial = tiempoEjecucionQueryInicial;
	}
	public static String getTiempoEjecucionAltaCentros() {
		return tiempoEjecucionAltaCentros;
	}
	public static void setTiempoEjecucionAltaCentros(String tiempoEjecucionAltaCentros) {
		Estadisticas.tiempoEjecucionAltaCentros = tiempoEjecucionAltaCentros;
	}
	public static String getTiempoEjecucionBajaCentros() {
		return tiempoEjecucionBajaCentros;
	}
	public static void setTiempoEjecucionBajaCentros(String tiempoEjecucionBajaCentros) {
		Estadisticas.tiempoEjecucionBajaCentros = tiempoEjecucionBajaCentros;
	}
	public static String getTiempoEjecucionCambioNombres() {
		return tiempoEjecucionCambioNombres;
	}
	public static void setTiempoEjecucionCambioNombres(String tiempoEjecucionCambioNombres) {
		Estadisticas.tiempoEjecucionCambioNombres = tiempoEjecucionCambioNombres;
	}
	public static String getTiempoEjecucionAltaAutorizados() {
		return tiempoEjecucionAltaAutorizados;
	}
	public static void setTiempoEjecucionAltaAutorizados(String tiempoEjecucionAltaAutorizados) {
		Estadisticas.tiempoEjecucionAltaAutorizados = tiempoEjecucionAltaAutorizados;
	}
	public static String getTiempoEjecucionBajasAutorizados() {
		return tiempoEjecucionBajasAutorizados;
	}
	public static void setTiempoEjecucionBajasAutorizados(String tiempoEjecucionBajasAutorizados) {
		Estadisticas.tiempoEjecucionBajasAutorizados = tiempoEjecucionBajasAutorizados;
	}
	public static String getTiempoEjecucionRegistrosManualesSemanaPasada() {
		return tiempoEjecucionRegistrosManualesSemanaPasada;
	}
	public static void setTiempoEjecucionRegistrosManualesSemanaPasada(
			String tiempoEjecucionRegistrosManualesSemanaPasada) {
		Estadisticas.tiempoEjecucionRegistrosManualesSemanaPasada = tiempoEjecucionRegistrosManualesSemanaPasada;
	}
	public static String getTiempoEjecucionRegistrosManualesSemanaActual() {
		return tiempoEjecucionRegistrosManualesSemanaActual;
	}
	public static void setTiempoEjecucionRegistrosManualesSemanaActual(
			String tiempoEjecucionRegistrosManualesSemanaActual) {
		Estadisticas.tiempoEjecucionRegistrosManualesSemanaActual = tiempoEjecucionRegistrosManualesSemanaActual;
	}
	public static String getTiempoEjecucionQueryRegistrosManuales() {
		return tiempoEjecucionQueryRegistrosManuales;
	}
	public static void setTiempoEjecucionQueryRegistrosManuales(String tiempoEjecucionQueryRegistrosManuales) {
		Estadisticas.tiempoEjecucionQueryRegistrosManuales = tiempoEjecucionQueryRegistrosManuales;
	}
	public static String getTiempoEjecucionFicheros() {
		return tiempoEjecucionFicheros;
	}
	public static void setTiempoEjecucionFicheros(String tiempoEjecucionFicheros) {
		Estadisticas.tiempoEjecucionFicheros = tiempoEjecucionFicheros;
	}
	public static String getTiempoEjecucionInsercionAltaAutorizados() {
		return tiempoEjecucionInsercionAltaAutorizados;
	}
	public static void setTiempoEjecucionInsercionAltaAutorizados(String tiempoEjecucionInsercionAltaAutorizados) {
		Estadisticas.tiempoEjecucionInsercionAltaAutorizados = tiempoEjecucionInsercionAltaAutorizados;
	}
	public static String getTiempoEjecucionInsercionBajasAutorizados() {
		return tiempoEjecucionInsercionBajasAutorizados;
	}
	public static void setTiempoEjecucionInsercionBajasAutorizados(String tiempoEjecucionInsercionBajasAutorizados) {
		Estadisticas.tiempoEjecucionInsercionBajasAutorizados = tiempoEjecucionInsercionBajasAutorizados;
	}
	public static String getTiempoEjecucionInsercionAltasManuales() {
		return tiempoEjecucionInsercionAltasManuales;
	}
	public static void setTiempoEjecucionInsercionAltasManuales(String tiempoEjecucionInsercionAltasManuales) {
		Estadisticas.tiempoEjecucionInsercionAltasManuales = tiempoEjecucionInsercionAltasManuales;
	}
	public static String getTiempoEjecucionInsercionBajasManuales() {
		return tiempoEjecucionInsercionBajasManuales;
	}
	public static void setTiempoEjecucionInsercionBajasManuales(String tiempoEjecucionInsercionBajasManuales) {
		Estadisticas.tiempoEjecucionInsercionBajasManuales = tiempoEjecucionInsercionBajasManuales;
	}
}
