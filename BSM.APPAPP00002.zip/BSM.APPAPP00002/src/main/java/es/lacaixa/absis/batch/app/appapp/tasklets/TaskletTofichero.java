package es.lacaixa.absis.batch.app.appapp.tasklets;

import java.io.File;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;

import es.lacaixa.absis.batch.app.appapp.domain.BeanCliente;
import es.lacaixa.absis.batch.app.appapp.util.Utilidades;
import es.lacaixa.absis.batch.arch.internal.util.AbsisFileSystemResource;
import es.lacaixa.absis.batch.arch.internal.writer.AbsisBeanWrapperFieldExtractor;
import es.lacaixa.absis.batch.arch.internal.writer.AbsisDelimitedLineAggregator;
import es.lacaixa.absis.batch.arch.internal.writer.AbsisFlatFileItemWriter;
import es.lacaixa.absis.batch.arch.util.BatchContext;

public class TaskletTofichero implements Tasklet {
	
	@javax.annotation.Resource(name="fileOutputAux")
	File fichero;
	
	
	String sql = "Select * from TDE_Cliente ";
	
	private AbsisFlatFileItemWriter writer;
	protected static Log logger = LogFactory.getLog(TaskletTofichero.class);
	
	public AbsisFlatFileItemWriter getWriter() {
		return writer;
	}

	public void setWriter(AbsisFlatFileItemWriter writer) {
		this.writer = writer;
	}
	
	
	
	@SuppressWarnings("rawtypes")
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		
		List<BeanCliente> listaclientes = Utilidades.readerClienteTasklet();
		BatchContext bc = BatchContext.getInstance();
		
		AbsisFlatFileItemWriter<BeanCliente> writer = new AbsisFlatFileItemWriter();
		writer.setResource(new AbsisFileSystemResource(fichero) );
		writer.setEncoding("ASCII");
		AbsisDelimitedLineAggregator lineAggregator = new AbsisDelimitedLineAggregator<>();
		lineAggregator.setDelimiter(";");
		AbsisBeanWrapperFieldExtractor fieldExtractor = new AbsisBeanWrapperFieldExtractor<>();
		String[] names = {"nombre","apellidos","telefono","nif"};
		fieldExtractor.setNames(names);
		fieldExtractor.afterPropertiesSet();
		lineAggregator.setFieldExtractor(fieldExtractor);
		writer.setLineAggregator(lineAggregator);
		writer.open(new ExecutionContext());
		writer.write(listaclientes);
		writer.close();
		return null;
	}
	
}
