package es.lacaixa.absis.batch.app.appapp.processors;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeanUtils;

import es.lacaixa.absis.batch.app.appapp.domain.BeanCliente;
import es.lacaixa.absis.batch.arch.internal.processor.AbsisGenericItemProcessor;

public class ProcesorCliente extends AbsisGenericItemProcessor<BeanCliente, BeanCliente>{
	protected static Log logger = LogFactory.getLog(ProcesorCliente.class);
	public static final String USU_ALTA_BATCH = "BATCH";
	
	@Override
	public BeanCliente process (BeanCliente inItem) throws Exception {
		
    	BeanCliente outItem = new BeanCliente();
    	BeanUtils.copyProperties(inItem, outItem);
    	
    
		
        return outItem;
    }
}