package es.lacaixa.absis.batch.app.appapp.tasklets;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;


import es.lacaixa.absis.batch.arch.util.BatchContext;
import es.lacaixa.qais.gtp.cache.Taux;

public class TaskletTauxPaises implements Tasklet{
	 
    protected static Log logger = LogFactory.getLog(TaskletTauxPaises.class);



	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		 
		  BatchContext bc = BatchContext.getInstance();
         Taux tx = bc.getComplexTaux("TAUX4650","es");
       
             if (tx != null) {
            	
               String campo = tx.getCampo("+039").substring(8,46).trim();          
               logger.info("PAIS:-> "+campo);

         }
		return null;
	}

}