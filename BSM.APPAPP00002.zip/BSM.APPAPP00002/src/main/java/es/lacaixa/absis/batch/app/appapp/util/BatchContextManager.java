package es.lacaixa.absis.batch.app.appapp.util;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import es.lacaixa.absis.batch.arch.util.BatchContext;
import es.lacaixa.absis.batch.arch.util.BatchParams;
import org.springframework.batch.core.StepExecution;

public class BatchContextManager {

    protected static Log log = LogFactory.getLog(BatchContextManager.class);

    private static long start = 0L;
    private static Map<String, Object> parameters;
    private static StepExecution currentStepExecution;

    public static BatchParams getBatchParams() {
        BatchContext batchContext = BatchContext.getInstance();

        if (batchContext == null) {
            return null;
        }

        return batchContext.getBatchParameters();
    }

    public static long getStart() {
        return start;
    }

    public static void setStart(long start) {
        BatchContextManager.start = start;
    }

    /**
     * @return the parameters
     */
    public static Map<String, Object> getParameters() {
        return parameters;
    }

    /**
     * @param parameters the parameters to set
     */
    public static void setParameters(Map<String, Object> parameters) {
        BatchContextManager.parameters = parameters;
    }

  
    public static StepExecution getCurrentStepExecution() {
        return currentStepExecution;
    }

  
    public static void setCurrentStepExecution(StepExecution stepExecution) {
        BatchContextManager.currentStepExecution = stepExecution;
    }
}
