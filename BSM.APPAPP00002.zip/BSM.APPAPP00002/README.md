SNB con estructura b�sica de directorios y ficheros que ejecuta un tasklet con logger:
- package beans con los xml necesarios para ejecutar el job
- packages complementarios como domain y util
- credentials.txt con los valores m�nimos necesarios para la ejecuci�n en local
- infJobAoe.properties con las propiedades necesarias para dar de alta la cadena con el SNB

Importante cambiar el literal "showcase" en los packages por el nombre de la aplicaci�n propietaria del SNB, as� como en el nombre del job y step en absis-batch-app-job.xml.